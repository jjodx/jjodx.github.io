function DemoVisuomotorRotation
% Demonstration of adaptation to a gain change between the mapping of the
% curor and the hand
%
% subjects must 1) before each trial click on the red target (starting point)
%               2) they must then shoot through the blue target at a
%               confortable speed and stop within the target
%               3) they are not allowed to stop, change trajectory or
%               correct their initial movement plan during their movement
%               4) Once they start, they must only stop after having
%               crossed the target
%               5) At the end of the movement, the target turns green

%% define figure
figure('units','normalized','Position', [0,0,1,1],'MenuBar', 'None');
axes('xlim',[-1.5 1.5],'ylim',[-1.5 1.5])
axis square
axis off
hold on

%% provide instructions
h=msgbox({'1) before each trial click on the red target (starting point)';,...
    '2) you must then shoot through the blue target at a confortable speed and stop within the target';...
    '3) you are not allowed to stop, change trajectory or correct their initial movement plan during their movement';...
    '4) Once they start, they must only stop after having crossed the target';...
    '5) At the end of the movement, the target turns green'});
p = get(h,'position');
p(3)=2.5*p(3);
p(4)=1.5*p(4);
set(h,'Position',p)
ah = get( h, 'CurrentAxes' );
ch = get( ah, 'Children' );
set( ch, 'FontSize', 20 );
waitfor(h)


%% define number of trials in each phase
Nbase = 10;%baseline
Nlearn = 45;%learning
Nwash = 10;%washout
Ntot = Nbase + Nlearn + Nwash;

%% Define target position
TarX = 0;
TarY = 1;
TarA = atan(TarY/TarX)*180/pi + 180*(TarX<0);
TarAngle = TarA*ones(Ntot,1);
%% define perturbation angle (deg)
Perturb = 45;


Err=zeros(Ntot,1);
for k=1:Ntot
    % define starting position
    a=plot(0,0, '.r', 'MarkerSize',45);
    pause(2)
    if k<=Nbase,
        [l,xs,ys]=RotCursor(0,TarX,TarY);
    elseif k<= Nlearn+Nbase,
        [l,xs,ys]=RotCursor(Perturb,TarX,TarY);
    else
        [l,xs,ys]=RotCursor(0,TarX,TarY);
    end
    Dist = sqrt(xs.^2 + ys.^2);
    I=find(Dist<0.5,1,'last');
    CursorAngle = atan(ys(I)/xs(I))*180/pi + 180*(xs(I)<0);
    Err(k) = TarAngle(k)-CursorAngle;
    pause(1)
    cla
end
close all
figure
plot(1:Ntot,Err,'-*r')
xlabel('trial number')
ylabel('error at the end of movement (deg)')

end

function [lineobj,xs,ys] = RotCursor(RotValue,TarX,TarY)
% This routine is a modified version of the FREEHANDDRAW routine, which is
% availale on matlab central http://www.mathworks.com/matlabcentral/fileexchange/7347-freehanddraw
%
%
% INPUT ARGUMENTS:  GainValue: default=1
%                   TarX, TarY: x-y position of the target to reach (will be normalized to an amplitude of 1)
%
% OUTPUT ARGUMENTS: 1) Handle to line object
%                  2) x-data of the movement
%                  3) y-data of the movement
% (Note that output args 2 and 3 can also be extracted from the first output
% argument.)
%

%Get current figure and axis parameters
oldvals = get(gcf);
oldhold = ishold(gca);

hold on;

set(gcf,'Pointer','circle','doublebuffer','on','UserData',RotValue);
if nargin<2,
    TarX=0;
    TarY =1;
else
    TarX = TarX/norm([TarX, TarY]);
    TarY = TarY/norm([TarX, TarY]);
end
b=plot(TarX,TarY, '.b', 'MarkerSize',69);
%Get the initial point
[xs,ys,zs] = ginput(1);

%Create and store line object

lineobj = line(xs,ys,'tag','tmpregsel');

setappdata(gcf,'lineobj',lineobj);

%Modify wbmf of current figure to update lineobject on mouse motion
set(gcf,'windowbuttonmotionfcn',@wbmfcn_J);
%Wait for right-click or double-click
while ~strcmp(get(gcf,'SelectionType'),'alt') & ~strcmp(get(gcf,'SelectionType'),'open')
	drawnow;
end
set(b,'color','g')
%Extract xyz data from line object for return in output variables
%(Also retrievable from first output argument)
if nargout > 1
	xs = get(getappdata(gcf,'lineobj'),'xdata')';
end
if nargout > 2
	ys = get(getappdata(gcf,'lineobj'),'ydata')';
end

%Clear temporary variables from base workspace
evalin('caller','clear tmpx tmpy tmpz done gca lineobj');

%Reset figure parameters
set(gcf,'windowbuttonmotionfcn',oldvals.WindowButtonMotionFcn,...
    'windowbuttondownfcn',oldvals.WindowButtonDownFcn);%,...
%'Pointer',oldvals.Pointer,...
% 	'doublebuffer',oldvals.DoubleBuffer);
%Reset hold value of the axis
if ~oldhold, hold off; end 
end

function wbmfcn_J(varargin)
% this function displays the (modified) cursor trajectory
%% make pointer invisible
set(gcf, 'PointerShapeCData', ones(16, 16)*nan);
set(gcf, 'Pointer', 'custom');
%% get the amplitude of the perturbation
RotParam=get(gcf,'UserData');
lineobj = getappdata(gcf,'lineobj');
if strcmp(get(gcf,'selectiontype'),'normal');
    tmpx = get(lineobj,'xdata');
    tmpy = get(lineobj,'ydata');
    % get pointer position
    a=get(gca,'currentpoint');
    % rotate cursor motion
    DATA = [a(1,1);a(1,2)]-[tmpx(1);tmpy(1)];
    ROT = [cos(RotParam*pi/180) sin(RotParam*pi/180);-sin(RotParam*pi/180) cos(RotParam*pi/180)];
    D = ROT*DATA;
    a = [tmpx(1);tmpy(1)]+D;
    % after movement end
    if sqrt(sum(D.^2))>.95,
         plot(a(1),a(2),'r*')
         set(gcf,'selectiontype','open')
    end
    % add latest point
    set(lineobj,'xdata',[tmpx,a(1)],'ydata',[tmpy,a(2)]);
    % update figure
    drawnow;
else
    setappdata(gcf,'lineobj',lineobj);
end
end