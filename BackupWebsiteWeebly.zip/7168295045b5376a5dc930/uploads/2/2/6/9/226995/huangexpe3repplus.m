function S = HuangExpe3RepPlus
% Demonstration of adaptation to a gain change between the mapping of the
% curor and the hand 
%
% subjects must 1) before each trial click on the red target (starting point)
%               2) they must then shoot through the blue target at a
%               confortable speed and stop within the target
%               3) they are not allowed to stop, change trajectory or
%               correct their initial movement plan during their movement
%               4) Once they start, they must only stop after having
%               crossed the target
%               5) At the end of the movement, the target turns green

%% define figure
figure('units','normalized','Position', [0,0,1,1],'MenuBar', 'None');
axes('xlim',[-1.5 1.5],'ylim',[-1.5 1.5])
axis square
axis off
hold on

%% provide instructions
h=msgbox({'1) before each trial click on the red target (starting point)';,...
    '2) you must then shoot through the blue target at a confortable speed and stop within the target';...
    '3) you are not allowed to stop, change trajectory or correct your movement on the fly';...
    '4) Do not stop before having crossed the target';...
    '5) At the end of the movement, the target turns green in case of succes and red otherwise'});
p = get(h,'position');
p(3)=2.5*p(3);
p(4)=1.5*p(4);
set(h,'Position',p)
ah = get( h, 'CurrentAxes' );
ch = get( ah, 'Children' );
set( ch, 'FontSize', 20 );
waitfor(h)


%% define number of trials in each phase
Nbase = 40;%baseline
Nlearn = 120;%learning
Nwash = 60;
Nlearn2 = 40;%washout
Ntot = Nbase + Nlearn + Nwash + Nlearn2;
Menu.Tt=uicontrol('style','edit','string','Remaining Trials','units','normalized','position',[.02 .735 .08 .04],'visible','on');
Menu.Tr=uicontrol('style','edit','string',num2str(Ntot),'units','normalized','position',[.02 .7 .08 .04],'visible','on');

points=0;
poi=0;
Menu.Tp=uicontrol('style','edit','string','Number of points','units','normalized','position',[.02 .835 .08 .04],'visible','on');
Menu.Po=uicontrol('style','edit','string',num2str(points),'units','normalized','position',[.02 .8 .08 .04],'visible','on');
setappdata(gcf,'P',points);
%% Define target position
A = (40:10:100);
TarX = cos(A*pi/180);
TarY = sin(A*pi/180);
TarA = atan(TarY/TarX)*180/pi + 180*(TarX<0);
% TarAngle = TarA*ones(Ntot,1);
%% define perturbation angle (deg)
Perturb = -30;
Perturb2 = 30;
Tn = 0;
Err=zeros(Ntot,1);
S = struct('Err',0,'Lx',[],'Ly',[]);
for k=1:Ntot
    % define starting position
    a=plot(0,0, '.r', 'MarkerSize',45);
%     pause(1)
    if k<=Nbase,
        Tn=mod(Tn,length(A));
        if Tn==0,
            TarChoice=randperm(7);
        end
        Tn=Tn+1;
        [l,xs,ys,ts]=RotCursor(0,TarX(TarChoice(Tn)),TarY(TarChoice(Tn)),1,0);
    elseif k<= Nlearn+Nbase,
        Tn=1;
        TarChoice=7;
        [l,xs,ys,ts]=RotCursor(Perturb,TarX(TarChoice(Tn)),TarY(TarChoice(Tn)),1,0);
    elseif k<= Nbase + Nlearn + Nwash,
        if k==Nbase + Nlearn+1,Tn=0;end;
        Tn=mod(Tn,length(A));
        if Tn==0,
            TarChoice=randperm(7);
        end
        Tn=Tn+1;
        [l,xs,ys,ts]=RotCursor(0,TarX(TarChoice(Tn)),TarY(TarChoice(Tn)),1,0);
    elseif k<= Nbase + Nlearn + Nwash + Nlearn2,
        Tn=1;
        TarChoice=1;
        [l,xs,ys,ts]=RotCursor(Perturb2,TarX(TarChoice(Tn)),TarY(TarChoice(Tn)),1,0);
    end
    Dist = sqrt(xs.^2 + ys.^2);
    I=find(Dist<0.5,1,'last');
    CursorAngle = atan(ys(I)/xs(I))*180/pi + 180*(xs(I)<0);
    Err(k) = A(TarChoice(Tn))-CursorAngle;
    S(k).Err = Err(k);
    S(k).Lx = xs;
    S(k).Ly = ys;
    S(k).T = ts-ts(1);
    S(k).Tar = TarChoice(Tn);
    set(Menu.Tr,'string',num2str(Ntot-k))
    if getappdata(gcf,'P'),
        poi = poi+1;
    end
    set(Menu.Po,'string',poi)
    pause(1.5)
    cla
end
close all
figure
plot(1:Ntot,Err,'-*r')
xlabel('trial number')
ylabel('error at the end of movement (deg)')
uisave('S')
end

function [lineobj,xs,ys,ts] = RotCursor(RotValue,TarX,TarY,visible,clamp)
% This routine is a modified version of the FREEHANDDRAW routine, which is
% availale on matlab central http://www.mathworks.com/matlabcentral/fileexchange/7347-freehanddraw
%
%
% INPUT ARGUMENTS:  GainValue: default=1
%                   TarX, TarY: x-y position of the target to reach (will be normalized to an amplitude of 1)
%
% OUTPUT ARGUMENTS: 1) Handle to line object
%                  2) x-data of the movement
%                  3) y-data of the movement
% (Note that output args 2 and 3 can also be extracted from the first output
% argument.)
%

if nargin<4,
    visible=1;
end

if nargin<5,
    clamp=0;
end

%Get current figure and axis parameters
oldvals = get(gcf);
oldhold = ishold(gca);

hold on;

set(gcf,'doublebuffer','on','UserData',RotValue);%'Pointer','circle',
if nargin<2,
    TarX=0;
    TarY =1;
else
    TarX = TarX/norm([TarX, TarY]);
    TarY = TarY/norm([TarX, TarY]);
end
b=plot(TarX,TarY, 'ob', 'MarkerSize',23);
%Get the initial point
xs=1;ys=1;
while sqrt(xs.^2 + ys.^2)>0.05
[xs,ys,zs] = ginput(1);
end

%Create and store line object

lineobj = line(xs,ys,cputime,'visible','off');%,'tag','tmpregsel'
setappdata(gcf,'StartingPoint',[xs,ys]);
if ~visible
    Vi = 'off';
else
    Vi='on';
end

C = plot(xs,ys,'b*','visible',Vi);

setappdata(gcf,'lineobj',lineobj);
setappdata(gcf,'cursor',C);
setappdata(gcf,'target',b);
setappdata(gcf,'Clamp',clamp);
%Modify wbmf of current figure to update lineobject on mouse motion
set(gcf,'windowbuttonmotionfcn',@wbmfcn_J);
%Wait for right-click or double-click
while ~strcmp(get(gcf,'SelectionType'),'extend')% & ~strcmp(get(gcf,'SelectionType'),'open')
	drawnow;
end

%Extract xyz data from line object for return in output variables
%(Also retrievable from first output argument)
if nargout > 1
	xs = get(getappdata(gcf,'lineobj'),'xdata')';
end
if nargout > 2
	ys = get(getappdata(gcf,'lineobj'),'ydata')';
end
if nargout > 3
	ts = get(getappdata(gcf,'lineobj'),'zdata')';
end

%Clear temporary variables from base workspace
evalin('caller','clear tmpx tmpy tmpz done gca lineobj');

%Reset figure parameters
set(gcf,'windowbuttonmotionfcn',oldvals.WindowButtonMotionFcn,...
    'windowbuttondownfcn',oldvals.WindowButtonDownFcn);%,...
if ~oldhold, hold off; end 
end

function wbmfcn_J(varargin)
% this function displays the (modified) cursor trajectory
%% make pointer invisible
set(gcf, 'PointerShapeCData', ones(16, 16)*nan);
set(gcf, 'Pointer', 'custom');
%% get the amplitude of the perturbation
RotParam=get(gcf,'UserData');
lineobj = getappdata(gcf,'lineobj');
Curse  = getappdata(gcf,'cursor');
StartPoint = getappdata(gcf,'StartingPoint');
b = getappdata(gcf,'target');
bx = get(b,'xdata');
by = get(b,'ydata');
TarA = atan(by/bx)*180/pi + 180*(bx<0);
CL = getappdata(gcf,'Clamp');
% if strcmp(get(gcf,'selectiontype'),'normal');
    tmpx = get(lineobj,'xdata');
    tmpy = get(lineobj,'ydata');
    tmpt = get(lineobj,'zdata');
    % get pointer position
    tim = cputime;
    a=get(gca,'currentpoint');
    tim=(tim+cputime)/2;
    % rotate cursor motion
    DATA = [a(1,1);a(1,2)]-[tmpx(1);tmpy(1)];
    ROT = [cos(RotParam*pi/180) sin(RotParam*pi/180);-sin(RotParam*pi/180) cos(RotParam*pi/180)];
    D = ROT*DATA;
    if ~CL,
        aa = [StartPoint(1);StartPoint(2)]+D;
        a=aa;
    else
        Dist = sqrt(sum(D.^2));
        aa = [StartPoint(1)+Dist*bx;StartPoint(2)+Dist*by];
        a = [StartPoint(1);StartPoint(2)]+D;
    end
    set(Curse,'xdata',aa(1),'ydata',aa(2))
    Cangle = atan(aa(2)/aa(1))*180/pi + 180*(aa(1)<0);
    % after movement end
    if sqrt(sum(D.^2))>.95,
         set(Curse,'color','k','visible','on')
         set(gcf,'selectiontype','extend')
         if CL || abs(TarA-Cangle)<8,
             %% binary feedback
             set(b,'color','g','marker','.','markersize',69)
%              points=getappdata(gcf,'P');
             points=1;
             setappdata(gcf,'P',points);
         else
             set(b,'color','r','linewidth',5)
             points=0;
             setappdata(gcf,'P',points);
         end
    end
    % add latest point
    set(lineobj,'xdata',[tmpx,a(1)],'ydata',[tmpy,a(2)],'zdata',[tmpt,tim]);

    drawnow;
% else
%     setappdata(gcf,'lineobj',lineobj);
% end
end