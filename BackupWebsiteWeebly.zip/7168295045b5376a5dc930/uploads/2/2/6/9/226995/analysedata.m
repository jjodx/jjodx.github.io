function AnalyseData


%% Movement time???

%% Here, specify the list of files that are available
Flist = {'KoenVandevoorde.mat';'KoenVandevoorde.mat'};
NF = length(Flist);%% Number of files
%% Data analysis Loop: for each subject
for i=1:length(Flist),
    %% load the matlab files
    load(Flist{i});
    %% initialization of variables
    if i==1,
        Err = NaN(NF,length(S));
        ErrLate = NaN(NF,length(S));
    end
    %% Error mid-movement
    %%% building matrix: one line per subject, one column per trial number
    Err(i,1:length(S))=[S.Err] +randn(1,length(S)); %%%  +randn(1,length(S)); for debugging purpose only
    %%%% Err is the error at the middle of the movement 
    %%%% So, let's see if this similar when
    %%%% the angle is computed at the end of the movement and the subject hasn't had time
    %%%% to correct for the perturbation.
    %% computing error at movement end: Loop for each trial
    for j = 1:length(S),
        %% 1) compute target angle because I forgot to save it.
        Dist = sqrt(S(j).Lx.^2 + S(j).Ly.^2);
        I=find(Dist<0.5,1,'last');
        CursorAngle = atan(S(j).Ly(I)/S(j).Lx(I))*180/pi + 180*(S(j).Lx(I)<0);
        TarAngle = S(j).Err + CursorAngle;
        %% 2) find hand position at movement end
        Ilast=find(Dist<1,1,'last');
        CursorAngle = atan(S(j).Ly(Ilast)/S(j).Lx(Ilast))*180/pi + 180*(S(j).Lx(Ilast)<0);
        %% 3) error at movement end
        ErrLate(i,j)=TarAngle-CursorAngle;
    end
end

%% display average error
if 1,%%% change to 0 if you don't want to see the figure
    F1=figure;
    %% mid-movement error
    subplot(1,2,1)
    plot(1:size(Err,2), mean(Err,1),'b.')
    xlabel('trial number')
    ylabel('error mid-movement (deg)')
    %% end-movement error
    subplot(1,2,2)
    plot(1:size(ErrLate,2), mean(ErrLate,1),'r.')
    xlabel('trial number')
    ylabel('error end movement(deg)')
end

%% initial learning: fit of an exponential function on the average error in the learning period

%%% to be modified in function of the paradigm%%%
L1 = 41;%%% first trial after baseline period
Lend = 100;%%% last trial of learning period
%%% to be modified %%%

%% fitting an exponential function: mid-movement
LearningValue = mean(Err(:,L1:Lend),1);%%% average error values over the course of the learning period
%%% non-linear fit of the exponential function:
FitAv = lsqnonlin(@single_exp, [LearningValue(1)-LearningValue(end) .01 LearningValue(end)], [], [], [], 0:length(LearningValue)-1,LearningValue);
%%% Second value in vector FitAv represents the learning rate

%% fitting an exponential function: end-movement
LearningValue2 = mean(ErrLate(:,L1:Lend),1);%%% average error values over the course of the learning period
%%% non-linear fit of the exponential function:
FitAv2 = lsqnonlin(@single_exp, [LearningValue2(1)-LearningValue2(end) .01 LearningValue2(end)], [], [], [], 0:length(LearningValue2)-1,LearningValue2);
%%% Second value in vector FitAv represents the learning rate

%% comparing data and fit:
figure(F1);
%% mid-movement error
subplot(1,2,1)
hold on;
xdata = 0:Lend-L1;
ydata = FitAv(1)*exp(-FitAv(2)*xdata)+FitAv(3);
plot(L1:Lend,ydata,'k')
hold off
%% end-movement error
subplot(1,2,2)
hold on;
ydata = FitAv2(1)*exp(-FitAv2(2)*xdata)+FitAv2(3);
plot(L1:Lend,ydata,'k')
hold off

%% comparing fit on single subject basis and fit on each subject
SubjectData = Err(:,L1:Lend);%%% data of the learning period for each subject
FitSub = NaN(NF,3);%%% initialization of matrix
%%% computing the values of the parameters of the exponential fit for each
%%% subject separately and storing in matrix FitSub
for j=1:NF,
    FitSub(j,:) = lsqnonlin(@single_exp, [SubjectData(j,1)-SubjectData(j,end) .01 SubjectData(j,end)], [], [], [], 0:length(SubjectData(j,:))-1,SubjectData(j,:));
end
F2=figure;
errorbar([-1,1],[FitAv(2) mean(FitSub(:,2))],[0 std(FitSub(:,2))/sqrt(NF)])
set(gca,'xtick',[-1,1],'xticklabel',{'Mean';'Indiv'},'xlim',[-2 2])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% testing the difference between feedforward and feedback
%%%% computing the curvature of the movement
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:length(Flist),
    load(Flist{i});
    %% initialization of variables
    if i==1,
        Curv = NaN(NF,length(S));
    end
    %%% for each trial
    for j = 1:length(S),
        %% 1) find relevant data
        Dist = sqrt(S(j).Lx.^2 + S(j).Ly.^2);
        %% 2) fit line
        [b,x_est,y_est] = DemingReg(S(j).Lx(Dist<1),S(j).Ly(Dist<1));
        %% 3) compute residuals
        ResDeming = sqrt((S(j).Lx(Dist<1)-x_est).^2 + (S(j).Ly(Dist<1)-y_est).^2);
        %%    Curvature: 
        Curv(i,j)=sum(ResDeming);
    end
end
%% plot of curvature
F3=figure;
xdata = 1:size(Curv,2);
ydata = mean(Curv,1);
plot(xdata,ydata,'k.')
xlabel('trial number')
ylabel('curvature of the movement')


%%%% Fitting a state-space model on the average error
Init=[0.2 .998];
options=optimset('Display','off','MaxIter',10000,'TolX',10^-30,'TolFun',10^-30);
data= mean(Err,1);
pStateSpace=fminsearch(@StateSpace,Init,options,data);


end


function y=StateSpace(p,data)
FR=p(2);%%% forgetting rate
B=p(1);%%% learning rate
Phi = NaN*ones(size(data));%%% represents hand direction
Phi(1)=0;

%%%% perturbation must be adapted for each experiment
Perturb = zeros(size(data));
Perturb(41:140)=30;
Perturb(141:180)=45;

N=length(data);
for k=2:N,
    if k<221,
        EC=1;
    else
        EC=0;
    end
    Err=data(k);
    Phi(:,k)=FR*Phi(:,k-1)+B*EC*Err;
end
y=sum(((Perturb-Phi)-data).^2);
end

function [y_diff, y_est] = single_exp(U, x, y_in)
%%%% typical exponential function where
%%%% 1)U is a vector that contains the three parameters of the exponential,
%%%% 2)x is the input of the function
%%%% 3)y_in is the data that must be fitted.

%%%% the output of the function is
%%%% 1) y_diff the residuals of the fit with the data (y_in)
%%%% 2) the estimated exponential function (y_est)
y_est = U(1).*exp(-U(2).*x) + U(3);
y_diff = y_in - y_est;
end

function [b,x_est,y_est] = DemingReg(x,y)
% deming regression from Matlab Central http://www.mathworks.com/matlabcentral/fileexchange/33484-linear-deming-regression
%
% deming() performs a linear Deming regression to find the linear
% coefficients:
%                     y = b(1) + b(2)*x
% under the assumptions that x and y *both* contain measurement error with
% measurement error variance related as lambda = sigma2_y/sigma2_x
% (sigma2_x and sigma2_y is the measurement error variance of the x and y
% variables, respectively).
%
% Computations are performed as described by Anders Christian Jenson in a
% May 2007 description of the Deming regression function for MethComp
% (web: http://staff.pubhealth.ku.dk/~bxc/MethComp/Deming.pdf), which
% includes a nice derivation of the slope, intercept, variance, and (x,y)
% estimates.
%
% Inputs: x         - [Nx1] Measured data w/ error
%         y         - [Nx1] Measured data w/ error

% Outputs: b        - [2x1] Intercept (1) and slope (2)
%          sigma2_x - [1x1] Error variance
%                           Note:  sigma2_y = lambda*sigma2_x
%          x_est    - [Nx1] Estimated x values
%          y_est    - [Nx1] Estimated y values

% Assign defaults
if nargin < 3
  lambda = 1;
end

% Check that x and y appear as expected
if length(x) ~= length(y)
  error('x and y must have the same length');
end
if size(x,2) > 1 || size(y,2) > 1
  error('x and y must both be vectors');
end

% Verify that lambda isn't anything unexpected
if numel(lambda) > 1
  error('lambda must be a scalar value');
end

% Set default value for alpha
if nargin < 4
  alpha = 0.05;
end

% Generate working variables
n            = length(y);  % Number of elements
m_x          = mean(x);    % Mean value of x
m_y          = mean(y);    % Mean value of y
c_xy         = cov(x,y);   % Covariance matrix of x and y
s_xx         = c_xy(1);    % Variance of x
s_xy         = c_xy(2);    % Covarince of x and y
s_yy         = c_xy(4);    % Variance of y
  
% Assign slope an intercept (in closed-form)
b            = zeros(2,1);
b(2)         = (s_yy - lambda*s_xx + sqrt((s_yy - lambda*s_xx).^2 + 4*lambda*s_xy^2)) ./ ...
               (2*s_xy);
b(1)         = m_y - b(2)*m_x;

% Don't compute x_est, y_est, and sigma2_x if they aren't requested
if nargout > 1

  % Assign x/y estimated values
  x_est        = x    + b(2)./(b(2).^2 + lambda)*(y - b(1) - b(2)*x);
  y_est        = b(1) + b(2)*x_est;
end

end
