%% Does between-group differences in mean influence the correlation between variables pooled across groups.

function []=CorrelationTwoAgeGroups(Niter)
%% function []=CorrelationTwoAgeGroups(Niter)
% This function investigates the effect of a categorical variable (in the
% study: age group: young (18-30yo) and old (55-70)) on the correlation
% between two variables X (in the study: working memory capacity) and Y (in
% the study: explicit component of motor adaptation). The two groups scored
% differently for the two variables. For the X variable, the difference
% between the two groups had an effect size d=0.93 (Cohen's d). For the Y
% variable, the difference had an effect size of d=0.2. This difference did
% not reach significance with our sample of N=31 per group.
%
% The goal of these simulations is to test how we can partial out the
% effect of age group on the relationship between X and Y. 
%
% First question: Does the between-group difference in X and Y lead to spurious
% correlations between X and Y. In other words, if X and Y are independent (no correlation),
% does the mean difference across groups affect the number of significant
% correlations that are found?
%
% Second question: can a multiple regression model like Y = A +B*X + C*G + D*XG (G is a categorical variable related to the groups)
% allow us to dissociate the effect of age group and the effect of the
% continuous dependent variable X on Y? In this case, in the absence of
% relationship between X and Y (no correlation) but in the presence of
% between-group differences in X and Y, the coefficient B should be
% significant only 5% of the time (false positive rate linked to significance threshold)

% number of iterations for the simulations
if nargin<1
    Niter=1000;
end


DeffectSizeWMC = 0.93;%%Cohen's D
DeffectSizeExplicit = 0.2;% = partial eta squared of 0.052 for E1b https://www.psychometrica.de/effect_size.html


%% choosing the assumption
% if Correlation =0, the routine makes the assumption that there is no correlation between the dependent and independent variable, therefore, the percentage of significant p-values to be equal to the significance threshold: 0.05
% if Correlation =1, the routine makes the assumption that there is a correlation between the dependent and independent variable, therefore, the percentage of significant p-values represents the power of the experiment.
% the strength of the correlation is proportional to the coefficient of the regression Y=Y+COEF*X
Correlation = 1;
COEF = 0.55;

ps = NaN(Niter,1);
pregs = NaN(Niter,3);
probs= NaN(Niter,3);
SampleSize = 31;%% same sample size as in the paper.

for k=1:Niter
    %%
    % independent variable X, effect size between group A and B = DeffectSizeWMC. In our paper, effect size is ~0.2 (partial eta squared of 0.052)
    
    % Gaussian distribution with mean=0, SD=1, old group in our paper
    Xa = randn(SampleSize,1);
    % Gaussian distribution with mean = DeffectSizeWMC, SD=1, young group in our paper
    Xb = DeffectSizeWMC+randn(SampleSize,1);
    X= [Xa;Xb];
    %%
    % dependent variable Y, effect size between group A and B = DeffectSizeExplicit
    
    % Gaussian distribution with mean=0, SD=1, old group in our paper
    Ya = randn(SampleSize,1);
    % Gaussian distribution with mean = DeffectSizeExplicit, SD=1, young group in our paper
    Yb = DeffectSizeExplicit+randn(SampleSize,1);
    Y= [Ya;Yb];
    
    % if there is a correlation, this is added here.
    if Correlation
        Y=Y+COEF*X;
        if k==Niter,disp('with correlation');end
    end
    
    
    % repartition of the groups, zero for old people and one for young ones
    G = [zeros(SampleSize,1);ones(SampleSize,1)];
    
    %% computation of the correlation without taking the difference in X and Y between the age groups into account
    [~,p]=corrcoef(X,Y);
    % p-value of the correlation are extracted here and stored in vector ps
    ps(k)=p(1,2);
    
    
    %% testing the effectiveness of a regression for partialling out the effect of age groups on the correlation
    % Here we replace the correlation by the regression with three independent
    % variables: X: WMC in our paper, G: the age group and an interaction X x G;
    % between X and G. The dependent variable is Y (explicit component of
    % adaptation in our paper).
    %%https://nl.mathworks.com/help/stats/understanding-linear-regression-outputs.html
    Xreg = [X G X.*G];
    lm = fitlm(Xreg,Y,'linear');
    tab=anova(lm);
    pregs(k,:)=tab.pValue(1:3)';
    
    [~,stats] = robustfit(Xreg,Y);
    probs(k,:)=stats.p(2:4)';
    if round(k/1000)==k/1000,disp(num2str(k));end
    
end
clc
%% results for the correlation between X and Y pooled across groups without taking bewtween-group differeces into account
% if Correlation =0,we expect that the percentage of significant correlation is equal to the significance threshold of 0.05. If correlation =1, then the percentage of significant correlation gives us a measure of the power.
disp(['false positive percentage: ' num2str(100*sum(ps<0.05)/Niter) ' % of correlations are significant'])
disp('------------------------------------------')
%% results for the regression between X and Y pooled across groups while taking bewtween-group differeces into account
% Here we test the model Y = A + B*X + C*G + D*X*G with normal regression
% if Correlation =0,we expect that the percentage of significant coefficient B is equal to 0.05 (false positive rate determined by significance threshold);
% The percentage of significant C coefficient should be higher given that there is a difference between the two groups for the X independent variable. The percentage of significant coefficients gives us a measure of the power.
% the percentage of significant coefficient B is equal to 0.05 (false positive rate determined by significance threshold);
% If correlation =1, then the percentage of significant B coefficient gives us a measure of the power to detect the actual relationship between Y and X
disp(['regression false positive percentage: '])
disp([num2str(100*sum(pregs(:,1)<0.05)/Niter) ' % of coefficient B (linked to variable X) are significant'])
disp([num2str(100*sum(pregs(:,2)<0.05)/Niter) ' % of coefficient C (linked to age group G) are significant'])
disp([num2str(100*sum(pregs(:,3)<0.05)/Niter) ' % of coefficient D (linked to interaction between X and G) are significant'])
disp('------------------------------------------')
% Here we test the model Y = A + B*X + C*G + D*X*G with robust regression
% interpretation is same as for the normal regression model above.
disp(['regression false positive percentage: '])
disp([num2str(100*sum(probs(:,1)<0.05)/Niter) ' % of coefficient B (linked to variable X) are significant'])
disp([num2str(100*sum(probs(:,2)<0.05)/Niter) ' % of coefficient C (linked to age group G) are significant'])
disp([num2str(100*sum(probs(:,3)<0.05)/Niter) ' % of coefficient D (linked to interaction between X and G) are significant'])

end


