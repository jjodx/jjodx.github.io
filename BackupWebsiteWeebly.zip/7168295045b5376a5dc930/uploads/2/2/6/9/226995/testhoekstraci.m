%%% confidence interval
%%% Number of repetitions
Rep=10000;
%%% Size of the sample population
n=20;

%%% the true mean is 0.25 and the true standard deviation is 0.75
%%% DATA is a Rep by n matrix. Each column represent a population of samples
TrueM = 0.25;
TrueSD = 0.75;
DATA = TrueM+TrueSD*randn(n,Rep);

%%% Z-value for computing confidence interval 1.96 for 95% CI and 2.575 for 99% CI
Z=2.575;

%%% computing sample mean, SD and CI for each population
M = mean(DATA);%% vector with Rep values
SD = std(DATA);%% vector with Rep values
CIlow = M-(Z*SD/sqrt(n));%% vector with Rep values
CIhigh = M + (Z*SD/sqrt(n));%% vector with Rep values

%%% to compute the probability that the TRUE mean is contained in the
%%% computed 95% confidence interval (actual definition)
P = 1-sum((CIlow>TrueM) + (CIhigh<TrueM))/Rep;

disp(['Prob that the true mean is contain in the CI: ' num2str(P)])

%%% to compute the probability that the SAMPLE mean is contained in the
%%% computed 95% confidence interval (actual misinterpretation)
for i=1:Rep,
    N(i)=sum((CIlow(i)<M).*(CIhigh(i)>M));
end
P2=(sum(N))/Rep^2;

disp(['Prob that the sample mean is contain in the CI: ' num2str(P2)])
