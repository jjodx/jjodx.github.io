function DemoGainAdaptation
% Demonstration of adaptation to a gain change between the mapping of the
% curor and the hand
%
% subjects must 1) before each trial click on the red target (starting point)
%               2) you must then reach as fast as possible to the blue
%               target and stop within the target
%               3) At the end of the movement, the target turns green

%% define figure
figure('units','normalized','Position', [0,0,1,1],'MenuBar', 'None');
axes
set(gca,'xlim',[-1.5 1.5],'ylim',[-1.5 1.5])
axis square
axis off
hold on

%% provide instructions
h=msgbox({'1) before each trial click on the red target (starting point)';,...
    '2) you must then reach as fast as possible to the blue target and stop within the target';...
    '3) At the end of the movement, the target turns green';});
p = get(h,'position');
p(3)=2.5*p(3);
p(4)=1.5*p(4);
set(h,'Position',p)
ah = get( h, 'CurrentAxes' );
ch = get( ah, 'Children' );
set( ch, 'FontSize', 20 );
waitfor(h)
%% define number of trials in each phase
Nbase = 10;%baseline
Nlearn = 45;%learning
Nwash = 10;%washout
Ntot = Nbase + Nlearn + Nwash;

%% Define target position (will be normalized to a distance of 1)
TarX = 0;
TarY = 1;
%% define gain magnitude
Gain = 2;

Err=zeros(Ntot,1);
for k=1:Ntot
    % define starting position
    a=plot(0,0, '.r', 'MarkerSize',45);
    pause(2)
    if k<=Nbase,
        [l,xs,ys]=ChangeGain(1,TarX,TarY);
    elseif k<= Nlearn+Nbase,
        [l,xs,ys]=ChangeGain(Gain,TarX,TarY);
    else
        [l,xs,ys]=ChangeGain(1,TarX,TarY);
    end
    Dist = sqrt(xs.^2 + ys.^2);
    [M,I]=max(Dist);
    
    Err(k) = Dist(3);
    pause(1)
    cla
end
close all
figure
% normalization of data with respect to baseline
B= mean(Err(1:Nbase));
plot(1:Ntot,Err/B,'-*r')
xlabel('trial number')
ylabel('normalized gain')
end
%% controlling one trial
function [lineobj,xs,ys] = ChangeGain(GainValue,TarX,TarY)
% This routine is a modified version of the FREEHANDDRAW routine, which is
% availale on matlab central http://www.mathworks.com/matlabcentral/fileexchange/7347-freehanddraw
%
%
% INPUT ARGUMENTS:  GainValue: default=1
%                   TarX, TarY: x-y position of the target to reach (will be normalized to an amplitude of 1)
%
% OUTPUT ARGUMENTS: 1) Handle to line object
%                  2) x-data of the movement
%                  3) y-data of the movement
% (Note that output args 2 and 3 can also be extracted from the first output
% argument.)
%


%% Get current figure and axis parameters
oldvals = get(gcf);
oldhold = ishold(gca);
%% figure options
hold on;
set(gcf,'Pointer','circle','doublebuffer','on','UserData',GainValue);

%% define and plot target position
if nargin<2,
    TarX=0;
    TarY =1;
else
    TarX = TarX/norm([TarX, TarY]);
    TarY = TarY/norm([TarX, TarY]);
end
b=plot(TarX,TarY, '.b', 'MarkerSize',69);
set(gca,'UserData',[TarX;TarY])
%% Get the initial point
[xs,ys,zs] = ginput(1);

%% Create and store line object
lineobj = line(xs,ys,'tag','tmpregsel');
setappdata(gcf,'lineobj',lineobj);

%% Modify wbmf of current figure to update lineobject on mouse motion
set(gcf,'windowbuttonmotionfcn',@wbmfcn_JJ);
set(gcf,'windowbuttondownfcn',@wbdfcn);
%% Wait until end of movement (originally right-click or double-click but here it is hacked)
while ~strcmp(get(gcf,'SelectionType'),'alt') & ~strcmp(get(gcf,'SelectionType'),'open')
    drawnow;
end
%% turn target green after end of trial
set(b,'color','g')
%% Extract xyz data from line object for return in output variables
%(Also retrievable from first output argument)
if nargout > 1
    xs = get(getappdata(gcf,'lineobj'),'xdata')';
end
if nargout > 2
    ys = get(getappdata(gcf,'lineobj'),'ydata')';
end

%% Reset figure parameters
set(gcf,'windowbuttonmotionfcn',oldvals.WindowButtonMotionFcn,...
    'windowbuttondownfcn',oldvals.WindowButtonDownFcn);%,...

%% Reset hold value of the axis
if ~oldhold, hold off; end
end

%%
%% displaying cursor trajectories
function wbmfcn_JJ(varargin)
% this function displays the (modified) cursor trajectory
%% make pointer invisible
set(gcf, 'PointerShapeCData', ones(16, 16)*nan);
set(gcf, 'Pointer', 'custom');
%% get the value of the gain
GainValue=get(gcf,'UserData');
lineobj = getappdata(gcf,'lineobj');
%% get tar position
TAR = get(gca,'UserData');
if strcmp(get(gcf,'selectiontype'),'normal');
    % get pointer position
    a=get(gca,'currentpoint');
    
    % after movement onset
    if sqrt(sum([a(1,1);a(1,2)].^2))>0.1,
        % scale cursor motion
        DATA = [a(1,1);a(1,2)];
        ROT = [GainValue 0; 0 GainValue];
        D = ROT*DATA;
        a = D;
        % get line position so far
        tmpx = get(lineobj,'xdata');
        tmpy = get(lineobj,'ydata');
        % detect movement end
        if sqrt(sum((a-TAR).^2))<0.05,
            b=[tmpx(end);tmpy(end)];
            % to avoid rapid shoot through the target
            if sqrt(sum((b-TAR).^2))<0.05,
                plot(a(1),a(2),'r*')
                % mimicking double-click
                set(gcf,'selectiontype','open')
            end
        end
        
        % add latest point
        set(lineobj,'xdata',[tmpx,a(1)],'ydata',[tmpy,a(2)]);
        % update figure
        drawnow;
    end
else
    setappdata(gcf,'lineobj',lineobj);
end
end